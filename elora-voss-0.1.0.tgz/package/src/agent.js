// Agent orchestrator. Runs the six phases sequentially and writes all output files.
import { readPreferences, appendTopic, workspaceInit } from './fs/workspace.js';
import { nextId, saveOutput } from './fs/history.js';
import { searchPhase } from './phases/search.js';
import { crosscheckPhase } from './phases/crosscheck.js';
import { knowledgePhase, saveKnowledgeBase } from './phases/knowledge.js';
import { verifyPhase } from './phases/verify.js';
import { writePhase } from './phases/write.js';
import { illustratePhase } from './phases/illustrate.js';

function progress(n, total, msg) {
  process.stdout.write(`[${n}/${total}] ${msg}\n`);
}

function fail(n, total, msg, err) {
  process.stderr.write(`[${n}/${total}] FAILED: ${msg}\n`);
  if (err?.stack) process.stderr.write(err.stack + '\n');
  process.exit(1);
}

function wordCount(s) {
  return s.trim().split(/\s+/).filter(Boolean).length;
}

/**
 * Run the full pipeline for a topic.
 * @param {string} topic
 */
export async function run(topic) {
  workspaceInit(); // ensure workspace exists before reading prefs
  const prefs = readPreferences();
  const id = nextId();
  const includeImages = String(prefs.INCLUDE_IMAGES || 'true').toLowerCase() === 'true';
  const totalPhases = includeImages ? 6 : 5; // illustrate is optional

  let kbPath = null;

  try {
    // Phase 1: Search
    progress(1, totalPhases, 'Searching the web...');
    const { provider, hits, notes } = await searchPhase(topic);
    if (hits.length === 0) {
      process.stderr.write(`Warning: search returned no hits for "${topic}". Continuing with limited context.\n`);
    }

    // Phase 2: Cross-check
    progress(2, totalPhases, 'Cross-checking facts...');
    const { claims, flagged } = await crosscheckPhase(notes, hits);

    // Phase 3: Knowledge base (saved to disk immediately)
    progress(3, totalPhases, 'Building knowledge base...');
    const kbRaw = await knowledgePhase(topic, claims, flagged, hits);
    kbPath = saveKnowledgeBase(id, topic, kbRaw);

    // Phase 4: Verify
    progress(4, totalPhases, 'Verifying knowledge base...');
    const kb = await verifyPhase(kbRaw);
    // Overwrite the saved KB with the verified version so disk matches what the writer saw.
    saveKnowledgeBase(id, topic, kb);

    // Phase 5: Write
    progress(5, totalPhases, 'Writing article...');
    let article = await writePhase(topic, kb, prefs);
    const title = `${topic[0].toUpperCase()}${topic.slice(1)}`;
    const fullOutput = `# ${title}\n\n${article}\n`;

    // Phase 6: Illustrate (optional)
    let images = [];
    if (includeImages) {
      progress(6, totalPhases, 'Finding images...');
      const result = await illustratePhase(article, prefs.IMAGE_PROVIDER || 'unsplash');
      images = result.images;
      article = result.article;
    }

    // Persist
    const finalOutput = `# ${title}\n\n${article}\n`;
    saveOutput(id, topic, finalOutput);

    const now = new Date().toISOString();
    appendTopic({
      id,
      topic,
      ranAt: now,
      wordCount: wordCount(article),
      contextFile: `context_${String(id).padStart(3, '0')}.md`,
      outputFile: `output_${String(id).padStart(3, '0')}.md`,
    });

    process.stdout.write(`\nDone. ${wordCount(article)} words written to output.txt\n`);
    if (images.length > 0) process.stdout.write(`Inserted ${images.length} images.\n`);
    if (kbPath) process.stdout.write(`Knowledge base: ${kbPath}\n`);
  } catch (err) {
    // If we got as far as phase 3, the KB is already on disk — tell the user.
    if (kbPath) {
      process.stderr.write(`\nKB saved to ${kbPath}. Article not produced.\n`);
    }
    fail(0, totalPhases, err.message || String(err), err);
  }
}