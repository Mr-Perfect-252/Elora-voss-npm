#!/usr/bin/env node
// elora-voss CLI entry. Dispatches argv to one of:
//   init | set-key <provider> <key> | research <topic...>
//   history | last | preferences | --version | --help

import { readFileSync, existsSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';

import { workspaceInit, PATHS } from './fs/workspace.js';
import { listHistory } from './fs/history.js';
import { setKey, getKey, listKeys } from './config.js';
import { run as runAgent } from './agent.js';
import { printBanner } from './ui/banner.js';

const { OUTPUT_FILE, PREFERENCES_FILE } = PATHS;

const __dirname = dirname(fileURLToPath(import.meta.url));
const PKG = JSON.parse(readFileSync(resolve(__dirname, '..', 'package.json'), 'utf8'));

const USAGE = `
elora-voss v${PKG.version}

Usage:
  elora-voss init                          Create local workspace files
  elora-voss set-key <provider> <key>      Save an API key (groq | tavily | unsplash)
  elora-voss keys                          Show which API keys are saved
  elora-voss research "<topic>"            Run the full research + writing pipeline
  elora-voss history                       List past research runs
  elora-voss last                          Print the most recent article
  elora-voss preferences                   Open preferences.txt in your editor
  elora-voss --version                     Show installed version
  elora-voss --help                        Show this help
`;

function exit(code, msg) {
  if (msg) process.stderr.write(msg + '\n');
  process.exit(code);
}

function cmdInit() {
  workspaceInit();
  process.stdout.write(`Created workspace in ${process.cwd()}\n`);
  process.stdout.write('  - preferences.txt\n');
  process.stdout.write('  - topics.csv\n');
  process.stdout.write('  - output.txt\n');
  process.stdout.write('  - history/\n');
  process.stdout.write('Next: elora-voss set-key groq YOUR_KEY\n');
}

function cmdSetKey(provider, key) {
  if (!provider || !key) exit(1, 'Usage: elora-voss set-key <provider> <key>');
  const valid = ['groq', 'tavily', 'unsplash'];
  if (!valid.includes(provider)) {
    exit(1, `Unknown provider "${provider}". Valid: ${valid.join(', ')}`);
  }
  setKey(provider, key);
  process.stdout.write(`Saved ${provider} key to ${process.cwd()}\\config\n`);
}

function cmdKeys() {
  const keys = listKeys();
  const providers = ['groq', 'tavily', 'unsplash'];
  for (const p of providers) {
    const v = keys[p];
    if (v) {
      const masked = v.length <= 8 ? '****' : `${v.slice(0, 4)}...${v.slice(-4)} (len=${v.length})`;
      process.stdout.write(`  ${p.padEnd(10)} ${masked}\n`);
    } else {
      process.stdout.write(`  ${p.padEnd(10)} (not set)\n`);
    }
  }
  process.stdout.write(`\nconfig file: ${process.cwd()}\\config\n`);
}

function cmdHistory() {
  const rows = listHistory();
  if (rows.length === 0) {
    process.stdout.write('No research runs yet. Try: elora-voss research "your topic"\n');
    return;
  }
  const header = ['ID', 'TOPIC', 'RAN AT', 'WORDS', 'FILES'];
  const data = rows.map((r) => [
    r.id,
    r.topic,
    r.ran_at,
    String(r.word_count),
    `${r.context_file} / ${r.output_file}`,
  ]);
  const widths = header.map((h, i) =>
    Math.max(h.length, ...data.map((row) => String(row[i]).length))
  );
  const fmt = (cells) => cells.map((c, i) => String(c).padEnd(widths[i])).join('  ');
  process.stdout.write(fmt(header) + '\n');
  process.stdout.write(widths.map((w) => '-'.repeat(w)).join('  ') + '\n');
  for (const row of data) process.stdout.write(fmt(row) + '\n');
}

function cmdLast() {
  if (!existsSync(OUTPUT_FILE)) {
    process.stdout.write('No output yet. Run: elora-voss research "<topic>"\n');
    return;
  }
  process.stdout.write(readFileSync(OUTPUT_FILE, 'utf8'));
}

function cmdPreferences() {
  const path = PREFERENCES_FILE;
  if (!existsSync(path)) {
    exit(1, 'Workspace not initialised. Run: elora-voss init');
  }
  const editor = process.env.VISUAL || process.env.EDITOR || (process.platform === 'win32' ? 'notepad' : 'nano');
  const parts = editor.split(/\s+/);
  const child = spawn(parts[0], [...parts.slice(1), path], { stdio: 'inherit', detached: true });
  child.on('error', (err) => exit(1, `Failed to open editor: ${err.message}`));
  child.unref();
}

async function cmdResearch(topic) {
  if (!topic) exit(1, 'Usage: elora-voss research "<topic>"');
  if (!getKey('groq')) {
    exit(1, 'Missing Groq API key. Run: elora-voss set-key groq YOUR_KEY');
  }
  await runAgent(topic);
}

async function main() {
  const argv = process.argv.slice(2);
  const cmd = argv[0];

  if (!cmd || cmd === '--help' || cmd === '-h') {
    printBanner(PKG.version);
    process.stdout.write(USAGE);
    return;
  }
  if (cmd === '--version' || cmd === '-v') {
    printBanner(PKG.version);
    process.stdout.write(`${PKG.version}\n`);
    return;
  }

  printBanner(PKG.version);
  switch (cmd) {
    case 'init':           return cmdInit();
    case 'set-key':        return cmdSetKey(argv[1], argv[2]);
    case 'keys':           return cmdKeys();
    case 'research':       return cmdResearch(argv.slice(1).join(' ').trim());
    case 'history':        return cmdHistory();
    case 'last':           return cmdLast();
    case 'preferences':    return cmdPreferences();
    default:               exit(1, `Unknown command: ${cmd}\n\n${USAGE}`);
  }
}

main().catch((err) => {
  process.stderr.write(`elora-voss: ${err.message}\n`);
  if (err.stack) process.stderr.write(err.stack + '\n');
  process.exit(1);
});