// Workspace management: files live directly in cwd (./preferences.txt, ./topics.csv,
// ./output.txt, ./config, ./history/). No workspace subfolder.
import { existsSync, mkdirSync, writeFileSync, readFileSync, appendFileSync } from 'node:fs';
import { resolve } from 'node:path';

const HISTORY_DIR = resolve('./history');

const PREFERENCES_FILE = resolve('./preferences.txt');
const TOPICS_FILE = resolve('./topics.csv');
const OUTPUT_FILE = resolve('./output.txt');

const DEFAULT_PREFERENCES = `# elora-voss preferences
# Edit this file to personalise your articles.
# Lines starting with # are comments and are ignored.

TONE=intelligent and narrative, like a magazine feature
LENGTH=long-form (800-1200 words)
NICHE=general science and technology
AUDIENCE=curious general readers with no specialist knowledge
LANGUAGE=English
STYLE=editorial essay
OUTPUT_FORMAT=markdown
INCLUDE_IMAGES=true
IMAGE_PROVIDER=unsplash
`;

const TOPICS_HEADER = 'id,topic,ran_at,word_count,context_file,output_file\n';

export function workspaceInit() {
  if (!existsSync(HISTORY_DIR)) mkdirSync(HISTORY_DIR, { recursive: true });

  if (!existsSync(PREFERENCES_FILE)) writeFileSync(PREFERENCES_FILE, DEFAULT_PREFERENCES, 'utf8');
  if (!existsSync(TOPICS_FILE)) writeFileSync(TOPICS_FILE, TOPICS_HEADER, 'utf8');
  if (!existsSync(OUTPUT_FILE)) writeFileSync(OUTPUT_FILE, '', 'utf8');

  return {
    historyDir: './history/',
    preferencesFile: PREFERENCES_FILE,
    topicsFile: TOPICS_FILE,
    outputFile: OUTPUT_FILE,
  };
}

export function readPreferences() {
  if (!existsSync(PREFERENCES_FILE)) {
    workspaceInit();
  }
  const raw = readFileSync(PREFERENCES_FILE, 'utf8');
  const out = {};
  for (const line of raw.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const eq = trimmed.indexOf('=');
    if (eq === -1) continue;
    const key = trimmed.slice(0, eq).trim();
    const value = trimmed.slice(eq + 1).trim();
    out[key] = value;
  }
  return out;
}

export function appendTopic({ id, topic, ranAt, wordCount, contextFile, outputFile }) {
  // CSV-escape topic (quote if it contains comma, quote, or newline)
  const esc = (s) => {
    const str = String(s);
    if (/[",\n\r]/.test(str)) return `"${str.replace(/"/g, '""')}"`;
    return str;
  };
  const row = `${id},${esc(topic)},${ranAt},${wordCount},${esc(contextFile)},${esc(outputFile)}\n`;
  appendFileSync(TOPICS_FILE, row, 'utf8');
}

export const PATHS = {
  HISTORY_DIR,
  PREFERENCES_FILE,
  TOPICS_FILE,
  OUTPUT_FILE,
};