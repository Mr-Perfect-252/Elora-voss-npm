// Thin wrapper around groq-sdk. One exported chat() function.

import Groq from 'groq-sdk';
import { getKey } from './config.js';

const DEFAULT_MODEL = 'llama-3.3-70b-versatile';

let _client = null;
function client() {
  if (_client) return _client;
  const key = getKey('groq');
  if (!key) throw new Error('Missing Groq API key. Run: elora-voss set-key groq YOUR_KEY');
  _client = new Groq({ apiKey: key });
  return _client;
}

/**
 * @param {string} systemPrompt
 * @param {string} userPrompt
 * @param {object} [opts]
 * @param {string} [opts.model]
 * @param {number} [opts.temperature]
 * @param {number} [opts.maxTokens]
 * @param {boolean} [opts.jsonMode] - request JSON object response
 * @returns {Promise<string>}
 */
export async function chat(systemPrompt, userPrompt, opts = {}) {
  const model = opts.model || DEFAULT_MODEL;
  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: userPrompt },
  ];
  const params = {
    model,
    messages,
    temperature: opts.temperature ?? 0.7,
    max_tokens: opts.maxTokens ?? 4096,
  };
  if (opts.jsonMode) params.response_format = { type: 'json_object' };

  const res = await client().chat.completions.create(params);
  const content = res.choices?.[0]?.message?.content ?? '';
  return content;
}

/** @returns {string} */
export function defaultModel() {
  return DEFAULT_MODEL;
}