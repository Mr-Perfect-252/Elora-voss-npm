// Pexels image search fallback. Free, no key required for limited use,
// but expects a PEXELS_API_KEY for production. If no key, returns empty.
import { getKey } from '../config.js';

const ENDPOINT = 'https://api.pexels.com/v1/search';

/**
 * @param {string} query
 * @param {number} [count=1]
 * @returns {Promise<{url:string,alt:string}[]>}
 */
export async function pexelsSearch(query, count = 1) {
  const apiKey = getKey('pexels');
  if (!apiKey) return [];

  const url = new URL(ENDPOINT);
  url.searchParams.set('query', query);
  url.searchParams.set('per_page', String(count));
  url.searchParams.set('orientation', 'landscape');

  const res = await fetch(url, { headers: { Authorization: apiKey } });
  if (!res.ok) return [];
  const data = await res.json();
  return (data.photos || []).map((photo) => ({
    url: photo.src?.large || photo.src?.medium || '',
    alt: photo.alt || query,
  }));
}