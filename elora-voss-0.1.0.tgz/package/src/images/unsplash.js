// Unsplash image search. Requires UNSPLASH API key.
import { getKey } from '../config.js';

const ENDPOINT = 'https://api.unsplash.com/search/photos';

/**
 * @param {string} query
 * @param {number} [count=1]
 * @returns {Promise<{url:string,alt:string}[]>}
 */
export async function unsplashSearch(query, count = 1) {
  const accessKey = getKey('unsplash');
  if (!accessKey) throw new Error('Unsplash key not set. Run: elora-voss set-key unsplash YOUR_KEY');

  const url = new URL(ENDPOINT);
  url.searchParams.set('query', query);
  url.searchParams.set('per_page', String(count));
  url.searchParams.set('orientation', 'landscape');

  const res = await fetch(url, { headers: { Authorization: `Client-ID ${accessKey}` } });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`Unsplash ${res.status}: ${text.slice(0, 200)}`);
  }
  const data = await res.json();
  return (data.results || []).map((photo) => ({
    url: photo.urls?.regular || photo.urls?.small || '',
    alt: photo.alt_description || query,
  }));
}