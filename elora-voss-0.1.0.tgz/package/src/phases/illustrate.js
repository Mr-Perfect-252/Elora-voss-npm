// Phase 6: Illustrate. Picks 3-5 moments in the article, fetches image URLs, inlines <img> tags.
import { chat } from '../groq.js';
import { unsplashSearch } from '../images/unsplash.js';
import { pexelsSearch } from '../images/pexels.js';
import { getKey } from '../config.js';

const SYSTEM = `You are an art director for narrative nonfiction. Given an article, identify 3 to 5 specific moments where an image would deepen the reader's experience. For each moment, output a short Unsplash-style search query (2-5 words, concrete noun phrase, no abstract concepts).

Return strict JSON: { "moments": [ { "after_paragraph": <1-based paragraph index>, "query": "..." } ] }

Rules:
- 3 <= number of moments <= 5
- Queries are concrete visual subjects (e.g., "particle collision", "sleeping brain", "milky way stars")
- No abstract queries ("truth", "existence", "meaning")
- Place each moment where the article reaches a visual pivot, not in transitions`;

/**
 * @param {string} article
 * @param {string} providerPref - "unsplash" or "pexels" from preferences
 * @returns {Promise<{images: {url:string,alt:string,query:string,provider:"unsplash"|"pexels"}[], article:string}>}
 */
export async function illustratePhase(article, providerPref = 'unsplash') {
  // Skip if no image key configured.
  const wantUnsplash = providerPref === 'unsplash';
  if (wantUnsplash && !getKey('unsplash')) {
    process.stdout.write('[6/6] No Unsplash key set — skipping images.\n');
    return { images: [], article };
  }

  const paragraphs = article.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
  const numbered = paragraphs.map((p, i) => `[${i + 1}] ${p}`).join('\n\n');

  const text = await chat(
    SYSTEM,
    `Article paragraphs (numbered):\n\n${numbered}`,
    { temperature: 0.5, maxTokens: 600, jsonMode: true }
  );

  let moments = [];
  try {
    const parsed = JSON.parse(text);
    moments = Array.isArray(parsed.moments) ? parsed.moments.slice(0, 5) : [];
  } catch {
    return { images: [], article };
  }
  if (moments.length < 3) return { images: [], article };

  // Fetch images in parallel.
  const images = [];
  for (const m of moments) {
    let img = null;
    try {
      if (wantUnsplash) {
        const res = await unsplashSearch(m.query, 1);
        if (res[0]) img = { ...res[0], query: m.query, provider: 'unsplash' };
      } else {
        const res = await pexelsSearch(m.query, 1);
        if (res[0]) img = { ...res[0], query: m.query, provider: 'pexels' };
        // Pexels fallback to unsplash if no key
        if (!img && getKey('unsplash')) {
          const res = await unsplashSearch(m.query, 1);
          if (res[0]) img = { ...res[0], query: m.query, provider: 'unsplash' };
        }
      }
    } catch {
      // skip this moment
    }
    if (img) images.push(img);
  }

  // Inline <img> tags at the chosen paragraph indices.
  // Build map: paragraph index (1-based) -> img
  const idxMap = new Map();
  moments.forEach((m, i) => {
    if (images[i]) idxMap.set(m.after_paragraph, images[i]);
  });

  const newParagraphs = paragraphs.map((p, i) => {
    const idx = i + 1;
    if (idxMap.has(idx)) {
      const img = idxMap.get(idx);
      return `${p}\n\n<img src="${img.url}" alt="${img.alt}" />`;
    }
    return p;
  });

  return { images, article: newParagraphs.join('\n\n') };
}