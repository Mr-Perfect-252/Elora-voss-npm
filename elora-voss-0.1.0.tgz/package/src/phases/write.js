// Phase 5: Write. Reads KB + preferences, writes a narrative article to spec's quality standard.
import { chat } from '../groq.js';

// The "quality bar" passage from the spec, embedded directly so the model has a single concrete target.
const QUALITY_BAR = `For every billion particles of antimatter born in the Big Bang, there were a billion and one particles of matter. That single extra particle — one in a billion — is the reason you exist. The reason anything exists. The universe is the leftover from an almost perfect catastrophe.`;

const SYSTEM = `You are a writer of narrative nonfiction. You write magazine-feature prose, not listicles, not structured breakdowns, not bullet summaries.

Every article you write must:
- Open with a hook — a striking fact, a contradiction, or a reframe that earns the next sentence
- Flow without headers — the writing carries the reader, not navigation labels
- Earn every claim — facts are explained and connected, not dropped
- Close with meaning — the last paragraph gives the reader something to carry

Your quality target is this passage (do not copy it, but every article you write should feel like it could open the same way):

"${QUALITY_BAR}"

You will be given a verified knowledge base and a set of personalisation preferences. Write a complete article that obeys the preferences. The article must be markdown with no headings — pure flowing prose. The first paragraph MUST be a hook. The final paragraph MUST give the reader something to carry.

You will also be told a minimum word count. Hit it. Going under is failure.

Output ONLY the article body. No preamble, no title, no metadata.`;

/**
 * Extract numeric floor from a LENGTH string like "long-form (800-1200 words)" or "1200 words".
 * @param {string} lengthStr
 * @returns {number}
 */
function lengthFloor(lengthStr) {
  const m = String(lengthStr || '').match(/(\d{3,4})/);
  return m ? parseInt(m[1], 10) : 800;
}

/**
 * @param {string} topic
 * @param {object} kb - verified knowledge base
 * @param {Record<string,string>} prefs
 * @returns {Promise<string>}
 */
export async function writePhase(topic, kb, prefs) {
  const floor = lengthFloor(prefs.LENGTH);
  const prefsBlock = Object.entries(prefs).map(([k, v]) => `${k}: ${v}`).join('\n');
  const kbBlock = `Summary:\n${kb.summary}\n\nFacts:\n${kb.facts.map((f) => `- [${(f.confidence || 'medium').toUpperCase()}] ${f.claim}`).join('\n')}\n\nFlagged / uncertain:\n${kb.flagged.join('\n') || '(none)'}\n\nSources:\n${kb.sources.join('\n')}`;

  const user = `Topic: ${topic}\n\nPreferences:\n${prefsBlock}\n\nKnowledge base:\n${kbBlock}\n\nMinimum word count: ${floor}. Write the full article now.`;

  let article = await chat(SYSTEM, user, { temperature: 0.85, maxTokens: 4000 });

  // Enforce minimum word count by asking for expansion if we're short.
  const countWords = (s) => s.trim().split(/\s+/).filter(Boolean).length;
  let attempts = 0;
  while (countWords(article) < floor && attempts < 2) {
    const expand = await chat(
      SYSTEM,
      `The article below is ${countWords(article)} words. The minimum is ${floor}. Expand it by deepening scenes, adding a concrete example, or extending the closing reflection. Output the full revised article — no preamble.`,
      { temperature: 0.85, maxTokens: 4000 }
    );
    article = expand;
    attempts++;
  }
  return article.trim();
}