// DuckDuckGo search provider. No API key required.
// duck-duck-scrape's safeSearch expects UPPERCASE enum ("STRICT" | "MODERATE" | "OFF").
// Passing lowercase throws "moderate is an invalid safe search type!".
import { search as ddgSearch } from 'duck-duck-scrape';
import { getKey } from '../config.js';

const VALID_SAFE_SEARCH = new Set(['STRICT', 'MODERATE', 'OFF']);

function tavilyHint() {
  return getKey('tavily')
    ? 'Tavily key is set — but the fallback in phases/search.js did not trigger. Check search.js.'
    : 'Try again, or set a Tavily key: elora-voss set-key tavily YOUR_KEY';
}

/**
 * @param {string} query
 * @param {number} [maxResults=10]
 * @returns {Promise<{title:string,url:string,snippet:string}[]>}
 */
export async function duckduckgoSearch(query, maxResults = 10) {
  const safeSearch = 'MODERATE';
  if (!VALID_SAFE_SEARCH.has(safeSearch)) {
    process.stderr.write(`[search] Invalid safeSearch value: ${safeSearch}\n`);
    return [];
  }
  let res;
  try {
    res = await ddgSearch(query, { safeSearch });
  } catch (err) {
    const msg = err && err.message ? err.message : String(err);
    process.stderr.write(`[search] DuckDuckGo failed: ${msg}\n`);
    process.stderr.write(`[search] ${tavilyHint()}\n`);
    return [];
  }
  if (!res) {
    process.stderr.write(`[search] DuckDuckGo returned no response.\n`);
    process.stderr.write(`[search] ${tavilyHint()}\n`);
    return [];
  }
  if (!res.results || res.results.length === 0) {
    process.stderr.write(`[search] DuckDuckGo returned 0 hits for "${query}".\n`);
    process.stderr.write(`[search] ${tavilyHint()}\n`);
    return [];
  }
  return res.results.slice(0, maxResults).map((r) => ({
    title: r.title || '',
    url: r.url || r.href || '',
    snippet: r.description || r.snippet || '',
  }));
}