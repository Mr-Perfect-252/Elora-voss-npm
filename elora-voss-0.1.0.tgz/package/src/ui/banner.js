// Terminal banner for elora-voss. Pure ANSI, no extra deps.
const RESET = '\x1b[0m';
const CYAN = '\x1b[36m';
const MAGENTA = '\x1b[35m';
const DIM = '\x1b[2m';

// "ELORA VOSS" in ASCII block letters. Each line is 80 cols wide.
// ELORA occupies cols 0-39, VOSS occupies cols 46-79, gap at 40-45.
const BANNER = [
  '███████╗██╗      ██████╗ ██████╗  █████╗      ██╗   ██╗ ██████╗ ███████╗███████╗',
  '██╔════╝██║     ██╔═══██╗██╔══██╗██╔══██╗     ██║   ██║██╔═══██╗██╔════╝██╔════╝',
  '█████╗  ██║     ██║   ██║██████╔╝███████║     ██║   ██║██║   ██║███████╗███████╗',
  '██╔══╝  ██║     ██║   ██║██╔══██╗██╔══██║     ╚██╗ ██╔╝██║   ██║╚════██║╚════██║',
  '███████╗███████╗╚██████╔╝██║  ██║██║  ██║      ╚████╔╝ ╚██████╔╝███████║███████║',
  '╚══════╝╚══════╝ ╚═════╝ ╚═╝  ╚═╝╚═╝  ╚═╝       ╚═══╝   ╚═════╝ ╚══════╝╚══════╝',
];

const TAGLINE = '  research and writing, terminal-native.';

function supportsColor() {
  if (process.env.NO_COLOR) return false;
  if (process.env.FORCE_COLOR) return true;
  return Boolean(process.stdout.isTTY);
}

export function printBanner(version) {
  // Skip banner entirely when output is piped (keeps scripts clean).
  if (!process.stdout.isTTY) return;
  if (process.env.NO_BANNER || process.env.CI) return;
  const useColor = supportsColor();
  const c = (code) => (useColor ? code : '');
  const split = 40;

  process.stdout.write('\n');
  for (const line of BANNER) {
    if (useColor) {
      process.stdout.write(
        `  ${c(CYAN)}${line.slice(0, split)}${c(RESET)}${c(MAGENTA)}${line.slice(split)}${c(RESET)}\n`
      );
    } else {
      process.stdout.write(`  ${line}\n`);
    }
  }
  const v = version ? `  v${version}` : '';
  process.stdout.write(`${c(DIM)}${TAGLINE}${c(RESET)}${v ? `  ${c(DIM)}${v}${c(RESET)}` : ''}\n\n`);
}

export { RESET, CYAN, MAGENTA, DIM };